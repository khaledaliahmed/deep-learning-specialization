#!/usr/bin/env bash

whisper utils/four-score.m4a --model large --language English 